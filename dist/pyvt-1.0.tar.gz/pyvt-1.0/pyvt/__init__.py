#!/usr/bin/env python

import os
from .visual_3d import main

def code_entry():
    main()

    return
